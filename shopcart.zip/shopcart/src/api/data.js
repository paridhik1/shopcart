const products = [
  {
    id: 01,
    name: 'Cool Vex',
    available_quantity: 5,
    price: 450,
    description: 'Lorem ipsum dolor sit amet, iusto appellantur vix te, nam affert feugait menandri eu. Magna simul ad est. Nostrum neglegentur ius at, at pertinax repudiare vel. Vim an adolescens quaerendum.'
  },
]